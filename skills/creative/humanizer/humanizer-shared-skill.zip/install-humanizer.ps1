﻿$ErrorActionPreference = "Stop"
$source = Join-Path $PSScriptRoot "humanizer"
if (-not (Test-Path (Join-Path $source "SKILL.md"))) { throw "Missing humanizer\SKILL.md" }
$targets = @(
    (Join-Path $HOME "AI-Skills-Library\humanizer"),
    (Join-Path $HOME ".agents\skills\humanizer"),
    (Join-Path $HOME ".claude\skills\humanizer")
)
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
foreach ($target in $targets) {
    if (Test-Path $target) {
        $backup = "$target.backup-$stamp"
        Copy-Item $target $backup -Recurse -Force
        Write-Host "Backed up existing skill to: $backup"
    }
    New-Item -ItemType Directory -Path $target -Force | Out-Null
    Copy-Item (Join-Path $source "SKILL.md") (Join-Path $target "SKILL.md") -Force
    $hash = (Get-FileHash (Join-Path $target "SKILL.md") -Algorithm SHA256).Hash
    Write-Host "Installed: $target | SHA256: $hash"
}
Write-Host "Local shared skill installed for master library, Codex, and Claude."
Write-Host "GitHub, Notion, and other agents are NOT synced by this script."

Humanizer shared skill

Extract this ZIP, then from PowerShell run:
powershell -ExecutionPolicy Bypass -File .\install-humanizer.ps1

Installs locally to AI-Skills-Library, .agents\skills, and .claude\skills.
Any existing humanizer folder is backed up first. GitHub/Notion/Grok aren't synced automatically.
